<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard testing <?php echo e(Auth::user()->name); ?></div>
                <ul class="list-group">
                <?php if(Auth::user()->name == 'admin'): ?>
                        <script type="text/javascript">
                            window.location = "{ url('/admin') }";
                        </script>
                        <li class="list-group-item"><a href="/admin">ADMIN PAGE</a></li>
                        <li class="list-group-item"><a href="/finance">FINANCE PAGE</a></li>
                        <li class="list-group-item"><a href="/sales">SALES PAGE</a></li>
                        <li class="list-group-item"><a href="/development">DEVELOPMENT PAGE</a></li>

                    <?php elseif(Auth::user()->name == 'finance'): ?>
                      
                        <li class="list-group-item"><a href="/finance">FINANCE PAGE</a></li>
                <?php elseif(Auth::user()->name == 'sales'): ?>

                        <li class="list-group-item"><a href="/sales">SALES PAGE</a></li>
                <?php elseif(Auth::user()->name == 'development'): ?>

                        <li class="list-group-item"><a href="/development">DEVELOPMENT PAGE</a></li>
                    <?php else: ?>

                <?php endif; ?>



                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </ul>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>