<?php echo $__env->yieldContent('content'); ?>
<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

</body>
</html>

<?php
/**
 * Created by PhpStorm.
 * User: maart
 * Date: 28-9-2017
 * Time: 12:08
 */