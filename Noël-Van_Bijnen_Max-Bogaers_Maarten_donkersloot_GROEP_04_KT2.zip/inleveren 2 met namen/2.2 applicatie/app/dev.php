<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dev extends Model
{
    protected  $table = "tbl_projects";
    protected $primaryKey = 'Project_ID';
}
