<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sales extends Model
{
   protected $table = "tbl_customers";
    protected $primaryKey = 'Customer_ID';
}
