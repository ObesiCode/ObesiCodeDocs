<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class finance extends Model
{
    protected $table = "tbl_offertes";
    protected $primaryKey = "invoice_ID";
}
