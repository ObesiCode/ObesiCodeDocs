function teset() {
    document.getElementById("help").innerHTML = "Hello JavaScript!";
}